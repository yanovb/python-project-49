import random


def make_random():
    return random.randint(1, 99)


def make_length_progression():
    return random.randint(5, 10)


def make_step():
    return random.randint(2, 5)
