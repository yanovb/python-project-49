import prompt


def engine(rules, qs_and_as):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print(rules)
    for q_and_a in qs_and_as:
        print(f'Question: {q_and_a[0]}')
        user_answer = prompt.string('Your answer: ')
        if user_answer != q_and_a[1]:
            print(f'"{user_answer}" is wrong answer ;(. Correct answer was "{q_and_a[1]}".')
            return
        else:
            print('Correct!')
    print(f'Congratulations, {name}!')
