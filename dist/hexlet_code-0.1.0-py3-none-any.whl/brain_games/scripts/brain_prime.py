#!/usr/bin/env python3
from brain_games.games.prime import make_prime


def main():
    make_prime()


if __name__ == '__main__':
    main()
