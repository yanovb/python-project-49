#!/usr/bin/env python3
from brain_games.games.gcd import make_gcd


def main():
    make_gcd()


if __name__ == '__main__':
    main()
